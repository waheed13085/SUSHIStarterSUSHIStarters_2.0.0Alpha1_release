       <div id="nav">
        <ul id="tabnav">
	   <li class="tab1"><a href="<?php echo $SSRoot; ?>">Home</a></li>
	   <li class="tab2"><a href="<?php echo $SSRoot.'config/'; ?>">Configure Services</a></li>
	   <li class="tab4"><a href="<?php echo $SSRoot.'get/'; ?>">Get Report</a></li>
	   <li class="tab6"><a href="<?php echo $SSRoot.'schedule/'; ?>">Schedule Report</a></li>
        </ul>
       </div>
