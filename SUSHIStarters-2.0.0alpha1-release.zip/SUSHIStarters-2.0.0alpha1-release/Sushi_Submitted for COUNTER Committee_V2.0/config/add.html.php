<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
  <head>
    <title>SUSHI</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link rel="stylesheet" href="<?php echo $SSRoot; ?>sushistarters.css" type="text/css" />
  </head>
  <body id="tab2">
    <div id="body-container">
      <?php include '../SSIncludes/header.inc.html.php'; ?>
      <?php include '../SSIncludes/nav.inc.html.php'; ?>
      <h2>Add new service provider</h2>
      <div id="fm-container">
        <form action="" method="post">
          <fieldset>
            <legend>Service Provider</legend>
              <p><label for="frmProviderName">Provider Name:</label>
                 <input type="text" class="wide-input" name="frmProviderName" value="<?php echo $ServiceProvider; ?>" /></p>
              <p><label for="frmServiceURL">Service URL:</label>
                 <input type="text" class="wide-input" name="frmServiceURL" value="<?php echo $ServiceURL; ?>" /></p>
              <p><label for="frmWSDLURL">WSDL:</label>
                 <input type="text" class="wide-input" name="frmWSDLURL" value="<?php echo $WSDLURL; ?>" />
                 </p>
                <fieldset>
                  <legend>Service type</legend>
                  <input type="radio" name="frmServiceType" id="frmServiceType" value="Service"
                    <?php if ($ServiceType == 'Service') echo 'checked'; ?> /> Production service&nbsp;
                  <input type="radio" name="frmServiceType" id="frmServiceType" value="Test"
                    <?php if ($ServiceType == 'Test') echo 'checked'; ?> /> Test service&nbsp;
                </fieldset>
          </fieldset>
          <fieldset>
              <legend>Requestor</legend>
              <p><label for="frmRequestorID">RequestorID:</label>
                 <input type="text" class="wide-input" name="frmRequestorID" value="<?php echo $RequestorID; ?>" /></p>
              <p><label for="frmRequestorName">RequestorName:</label>
                 <input type="text" class="wide-input" name="frmRequestorName" value="<?php echo $RequestorName; ?>" /></p>
              <p><label for="frmRequestorEmail">Requestor email:</label>
                 <input type="text" class="wide-input" name="frmRequestorEmail" value="<?php echo $RequestorEmail; ?>" /></p>
          </fieldset>
          <fieldset>
              <legend>CustomerReference</legend>
              <p><label for="frmCustomerReferenceID">CustomerReferenceID:</label>
                 <input type="text" class="wide-input" name="frmCustomerReferenceID" value="<?php echo $CustomerReferenceID; ?>" /></p>
              <p><label for="frmCustomerReferenceName">CustomerReferenceName:</label>
                 <input type="text" class="wide-input" name="frmCustomerReferenceName" value="<?php echo $CustomerReferenceName; ?>" /></p>
          </fieldset>
          <fieldset>
            <legend>COUNTER Reports Available</legend>
                <fieldset>
                  <legend>Book Reports (Release 1)</legend>
                    <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="BR1"
                       <?php if (my_in_array("BR1", $Reports)) echo "checked"; ?> />BR1</label>
                    <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="BR2"
                       <?php if (my_in_array("BR2", $Reports)) echo "checked"; ?> />BR2</label>
                    <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="BR3"
                       <?php if (my_in_array("BR3", $Reports)) echo "checked"; ?> />BR3</label>
                    <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="BR4"
                       <?php if (my_in_array("BR4", $Reports)) echo "checked"; ?> />BR4</label>
                    <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="BR5"
                       <?php if (my_in_array("BR5", $Reports)) echo "checked"; ?> />BR5</label>
                    <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="BR7"
                       <?php if (my_in_array("BR6", $Reports)) echo "checked"; ?> />BR7</label>
                </fieldset>
                <fieldset>
                  <legend>Consortium Reports (Release 3)</legend>
                    <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="CR1"
                       <?php if (my_in_array("CR1", $Reports)) echo "checked"; ?> />CR1</label>
                    <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="CR2"
                       <?php if (my_in_array("CR2", $Reports)) echo "checked"; ?> />CR2</label>
					<label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="CR3"
                       <?php if (my_in_array("CR3", $Reports)) echo "checked"; ?> />CR3</label>
                </fieldset>
                <fieldset>
                  <legend>Database Reports (Release 3)</legend>
                     <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="DB1"
                       <?php if (my_in_array("DB1", $Reports)) echo "checked"; ?> />DB1</label>
                     <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="DB2"
                       <?php if (my_in_array("DB2", $Reports)) echo "checked"; ?> />DB2</label>
                </fieldset>
				<fieldset>
                  <legend>Platform Reports (Release 3)</legend>
                     <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="PR1"
                       <?php if (my_in_array("PR1", $Reports)) echo "checked"; ?> />PR1</label>
                </fieldset>
				<fieldset>
                  <legend>Media Reports (Release 3)</legend>
                     <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="MR1"
                       <?php if (my_in_array("MR1", $Reports)) echo "checked"; ?> />MR1</label>
                     <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="MR2"
                       <?php if (my_in_array("MR2", $Reports)) echo "checked"; ?> />MR2</label>
                </fieldset>
                <fieldset>
                  <legend>Journal Reports (Release 3)</legend>
                    <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="JR1"
                       <?php if (my_in_array("JR1", $Reports)) echo "checked"; ?> />JR1</label>
                    <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="JR1a"
                       <?php if (my_in_array("JR1a", $Reports)) echo "checked"; ?> />JR1a</label>
                    <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="JR2"
                       <?php if (my_in_array("JR2", $Reports)) echo "checked"; ?> />JR2</label>
                    <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="JR3"
                       <?php if (my_in_array("JR3", $Reports)) echo "checked"; ?> />JR3</label>
                    <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="JR4"
                       <?php if (my_in_array("JR4", $Reports)) echo "checked"; ?> />JR4</label>
                    <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="JR5"
                       <?php if (my_in_array("JR5", $Reports)) echo "checked"; ?> />JR5</label>
					<label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="JR3mobile"
                       <?php if (my_in_array("JR3mobile", $Reports)) echo "checked"; ?> />JR3M</label>
					<label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="JR1GOA"
                       <?php if (my_in_array("JR1GOA", $Reports)) echo "checked"; ?> />JR1GOA</label>
                </fieldset>
				<fieldset>
                  <legend>Title Reports (Release 3)</legend>
                    <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="TR1"
                       <?php if (my_in_array("TR1", $Reports)) echo "checked"; ?> />TR1</label>
                    <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="TR2"
                       <?php if (my_in_array("TR2", $Reports)) echo "checked"; ?> />TR2</label>
					<label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="TR3"
                       <?php if (my_in_array("TR3", $Reports)) echo "checked"; ?> />TR3</label>
					<label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="TR1mobile"
                       <?php if (my_in_array("TR1mobile", $Reports)) echo "checked"; ?> />TR1M</label>
                    <label class="checkbox"><input type="checkbox" name="frmReportName[]" id="frmReportName" value="TR3mobile"
                       <?php if (my_in_array("TR3mobile", $Reports)) echo "checked"; ?> />TR3M</label>
                    
                </fieldset>

          </fieldset>
          <fieldset>
            <legend>Instructions</legend>
              <label for="frmInstructions">Notes on service:</label>
              <textarea name="frmInstructions" id="frmInstructions"><?php htmlout($Instructions); ?></textarea>
          </fieldset>
          <div id="fm-submit">
            <input type="hidden" name="addService" value="Add service"/>
            <input type="submit" name="addService"  class="fm-submit" value="Add Service"/>
          </div>
        </form>
      </div>
      <div id="sidebar-help">
        <h2>Help</h2>
        <h3>WSDL</h3>
        <p>Set the WSDL to 'COUNTER' to use the canonical WSDL (counter_sushi3_0.wsdl) hosted on the NISO website - it works well for most providers.</p>
        <p>If that doesn't work, you will need to ascertain and enter the Service Provider's WSDL URL instead.</p>
		<p>If WSDL is not supported by the vendor; place the URL in Service URL textbox and in WSDL enter 'COUNTER'</p> 
      </div>
      <?php include '../SSIncludes/footer.inc.html.php'; ?>
    </div>
  </body>
</html>