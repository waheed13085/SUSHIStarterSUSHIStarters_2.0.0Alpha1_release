    <div id="footer">
      &copy; 2011-<?php echo $YYYY; ?>
    </div>
