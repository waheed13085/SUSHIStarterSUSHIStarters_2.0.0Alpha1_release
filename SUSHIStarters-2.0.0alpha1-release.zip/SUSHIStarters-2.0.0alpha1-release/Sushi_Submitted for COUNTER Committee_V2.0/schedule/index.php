<?php

  include_once '..\SSIncludes/helpers.inc.php';
  include 'schedule.html.php';

?>